<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>View Disease Symptom Mapping</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet">
</head>

<body>

    <!-- HEADER -->
    <?php include "../includes/header.php" ?>

    <div class="container mt-5">
        <h3 class="mb-4">View Disease Symptom Mapping</h3>

        <?php
        include '../config/db.php';
        $conn = mysqli_connect(HOSTNAME, USERNAME, PASSWORD, DBNAME);
        if (!$conn) {
            die("Connection Failed: " . mysqli_connect_error());
        }

        $qry = "SELECT * FROM disease_symptom";
        $result = mysqli_query($conn, $qry);

        if (mysqli_num_rows($result) > 0) {

            // Header Row
            echo "<div class='row mb-2 fw-bold'>";
            echo "<div class='col'>ID</div>";
            echo "<div class='col'>Disease ID</div>";
            echo "<div class='col'>Symptom ID</div>";
            echo "<div class='col'>Action</div>";
            echo "</div>";

            // Data Rows
            while ($row = mysqli_fetch_array($result)) {
                echo "<div class='row mb-2'>";
                echo "<div class='col'>$row[0]</div>";
                echo "<div class='col'>$row[1]</div>";
                echo "<div class='col'>$row[2]</div>";
                echo "<div class='col'>
                    <a class='btn btn-info btn-sm me-2' href='add_disease_symptom.php?id=$row[0]'>Edit</a>
                    <a class='btn btn-warning btn-sm' href='delete_disease_symptom.php?id=$row[0]'>Delete</a>
                  </div>";
                echo "</div>";
            }
        } else {
            echo "<h4 class='text-warning'>No Record Found !!!</h4>";
        }

        mysqli_close($conn);
        ?>

        <a class="btn btn-secondary m-3" href="../admin/dashboard.php">Back to Dashboard</a>
    </div>

    <!-- FOOTER -->
    <?php include "../includes/footer.php" ?>

</body>

</html>