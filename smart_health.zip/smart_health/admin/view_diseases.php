<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Smart Health Prediction System</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-sRIl4kxILFvY47J16cr9ZwB07vP4J8+LH7qKQnuqkuIAvNWLzeN8tE5YBujZqJLB" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/js/bootstrap.bundle.min.js" integrity="sha384-FKyoEForCGlyvwx9Hj09JcYn3nv7wiPVlz7YYwJrWVcXK/BmnVDxM+D2scQbITxI" crossorigin="anonymous"></script>
</head>

<body>
    <!-- HEADER -->
    <?php include "../includes/header.php" ?>

    <div class="container mt-5">
        <h3 class="mb-4">View Diseases</h3>
        <?php
        include '../config/db.php';
        $conn = mysqli_connect(HOSTNAME,USERNAME,PASSWORD,DBNAME);
        $qry = "select * from diseases";
        // RESULTSET
        $result = mysqli_query($conn, $qry);

        if (mysqli_num_rows($result) >  0) {
            echo "<table class='table table-striped  table-hover table-bordered'>";
            echo "<tr class='table-dark'>";
            echo "<th>Disease ID</th>";
            echo "<th>Disease Name</th>";
            echo "<th>Description</th>";
            echo "<th>Action</th>";
            echo "</tr>";

            // TO DISPLAY TABLE ON SCREEN FORM DATABASE
            while ($row = mysqli_fetch_array($result)) {
                echo "<tr>";
                echo "<td>$row[0]</td>";
                echo "<td>$row[1]</td>";
                echo "<td>$row[2]</td>";
                echo "<td><a class = 'btn btn-info btn-sm me-3' href='add_disease.php?ddid=$row[0]'>Edit</a> <a class = 'btn btn-warning btn-sm' href='delete_disease.php?ddid=$row[0]'>Delete</a></td>";
                 echo "</tr>";
            }
            echo "</table>";
        } else {
            echo "<h2 class='text-warning'> No Record Found !!! </h2>";
        }
        ?>

        <a class="btn btn-secondary m-3" href="../admin/dashboard.php">Back to Dashboard</a>
    </div>

    <!-- FOOTER -->
    <?php include "../includes/footer.php" ?>
</body>

</html>