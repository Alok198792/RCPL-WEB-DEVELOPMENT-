<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Smart Health Prediction System</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-sRIl4kxILFvY47J16cr9ZwB07vP4J8+LH7qKQnuqkuIAvNWLzeN8tE5YBujZqJLB" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/js/bootstrap.bundle.min.js" integrity="sha384-FKyoEForCGlyvwx9Hj09JcYn3nv7wiPVlz7YYwJrWVcXK/BmnVDxM+D2scQbITxI" crossorigin="anonymous"></script>
</head>

<body>
    <!-- HEADER -->
    <?php include "../includes/header.php" ?>

    <div class="container mt-5">
        <h3 class="mb-4">View Doctors</h3>
        <?php
        $conn = mysqli_connect("localhost", "root", "", "smart_health");
        $qry = "select * from doctors";
        // RESULTSET
        $result = mysqli_query($conn, $qry);

        //  if (mysqli_num_rows($result) >  0) {
        //     echo "<table class='table table-striped  table-hover table-bordered'>";
        //     echo "<tr class='table-dark'>";
        //     echo "<th>Doctor ID</th>";
        //     echo "<th>Doctor Name</th>";
        //     echo "<th>Specialization</th>";
        //     echo "<th>Contact</th>";
        //     echo "<th>Action</th>";
        // echo "</tr>";
        if (mysqli_num_rows($result) >  0) {
            echo "<div class='row mb-2 fw-bold'>";
            echo "<div class='col'>Doctor ID</div>";
            echo "<div class='col'>Doctor Name</div>";
            echo "<div class='col'>Specialization</div>";
            echo "<div class='col'>Contact</div>";
            echo "<div class='col'>Action</div>";
            echo "</div>";


            // TO DISPLAY TABLE ON SCREEN FORM DATABASE
            while ($row = mysqli_fetch_array($result)) {
                echo "<div class='row mb-2'>";
                echo "<div class = 'col'>$row[0]</div>";
                echo "<div class = 'col'>$row[1]</div>";
                echo "<div class = 'col'>$row[2]</div>";
                echo "<div class = 'col'>$row[3]</div>";
                echo "<div class = 'col'><a class = 'btn btn-info btn-sm me-3' href='add_doctor.php?did=$row[0]'>Edit</a> <a class = 'btn btn-warning btn-sm' href='delete_doctor.php?did=$row[0]'>Delete</a></div>";
                echo "</div>";
            }
         } else {
            echo "<h2 class='text-warning'> No record Found !!! </h2>";
        }
        ?>

        <a class="btn btn-secondary m-3" href="../admin/dashboard.php">Back to Dashboard</a>
    </div>

    <!-- FOOTER -->
    <?php include "../includes/footer.php" ?>
</body>

</html>