<?php 
$id = $_GET['ddid'];
include '../config/db.php';
$conn = mysqli_connect(HOSTNAME,USERNAME,PASSWORD,DBNAME);
$qry = "delete from diseases where disease_id=$id";
mysqli_query($conn,$qry);
header("location:view_diseases.php");
?>