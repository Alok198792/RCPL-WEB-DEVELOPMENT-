 <!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Smart Health Prediction System</title>
    
</head>
<body>
     <div class="container-fluid">
        <?php include "nav.php" ?>

ffghfh
        <?php include "footer.php" ?>
    </div>
</body>
</html>