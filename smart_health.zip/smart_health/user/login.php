<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Smart Health Prediction System</title>
</head>

<body>
    <div class="container-fluid">
    <?php include "../nav.php" ?>
    <div class="row m-5">
        <div class="col-sm-4"></div>
          <div class="col-sm-3 shadow">  <!--shadow-sm ,shadow-lg -->
             <form>
                    <div class="row">
                        <h2 class=" text-center">User Login</h2>
                    </div>
                    
                    <!-- EMAIL ID OR PHONE NO -->
                     <div class="mt-2">
                        <!-- <label class="form-label text-dark">E-mail id or Phone number -</label> -->
                        <input class="form-control" type="email" name="t1" value="" placeholder="E-mail" required/>
                    </div>
                     <!-- PASSWORD -->
                     <div class="mt-2">
                        <!-- <label class="form-label text-dark">Password -</label> -->
                        <input class="form-control" type="password" name="t1" value="" placeholder="Password" required/>
                    </div>
                    
                    <!-- BUTTON -->
                     <div class="col-sm-12 mt-3 mb-3">
                        <div class="d-grid">
                        <button class="btn btn-success btn-outline-info btn-block text-light" type="submit">Login</button>
                    </div>
                     </div>

                </form>
          </div>
          <!-- <div class="col-sm-5"></div>   -->
        </div>
        <?php include "../footer.php" ?>

    </div>
    
    
    
    
</div>

</body>

</html>