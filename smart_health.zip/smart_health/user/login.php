<?php
$msg = "";
if (isset($_POST['btn_login'])) {
    $username = $_POST['username'];
    $password = $_POST['password'];
    include '../config/db.php';
    $conn = mysqli_connect(HOSTNAME, USERNAME, PASSWORD, DBNAME);
    $qry = "select * from users where email ='$username' and password ='$password'";
    $result = mysqli_query($conn, $qry);
    if (mysqli_num_rows($result) > 0) {
        $r = mysqli_fetch_array($result);
        session_start();
        $_SESSION['uid'] = $r['id'];
        header("location:select_symptoms.php");
    } else {
        $msg = "<b class='text-danger m-5'> Invalid Username and Password </b>";
        mysqli_close($conn);
    }
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Smart Health Prediction System</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-sRIl4kxILFvY47J16cr9ZwB07vP4J8+LH7qKQnuqkuIAvNWLzeN8tE5YBujZqJLB" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/js/bootstrap.bundle.min.js" integrity="sha384-FKyoEForCGlyvwx9Hj09JcYn3nv7wiPVlz7YYwJrWVcXK/BmnVDxM+D2scQbITxI" crossorigin="anonymous"></script>
    <link rel=stylesheet href="../css/style.css" > 
</head>

<body>
    <!-- HEADER -->
    <?php include "../includes/header.php" ?>


    <div class="container mt-5" style="min-height:593px;">
        <div class="card mx-auto shadow" style="max-width:400px;">
            <div class="card-body"> <!--shadow-sm ,shadow-lg -->
                <h4 class="text-center">User Login</h4>
                <form method="post">

                    <input type="email" name="username" class="form-control mb-3" value="<?php
                                                                                            if (isset($_COOKIE['mail']))
                                                                                                echo $_COOKIE['mail'];
                                                                                            ?>" placeholder="Email" required>

                    <input type="password" name="password" class="form-control mb-3" value="<?php
                                                                                            if (isset($_COOKIE['pwd']))
                                                                                                echo $_COOKIE['pwd'];
                                                                                            ?>" placeholder="Password" required>

                    <input type="checkbox" name="rem" value="yes"><label>Remember me!!! </label><br>

                    <button type="submit" name="btn_login" class="btn btn-primary w-100">Login</button>
                </form>
                <?php
                 echo $msg;
                if (isset($_POST['btn_login'])) {
                    $em = $_POST['username'];
                    $pass = $_POST['password'];
                    if (isset($_POST['rem'])) {
                        setcookie("mail", $em, time() + 60 * 60 * 24);
                        setcookie("pwd", $pass, time() + 60 * 60 * 24);
                    }
                }
                ?>
                 
            </div>
        </div>

    </div>


    <!-- FOOTER -->
    <?php include "../includes/footer.php" ?>


</body>

</html>