<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Smart Health Prediction System</title>
</head>

<body>
    <div class="container-fluid">
    <?php include_once "../nav.php" ?>
    <div class="row m-5">
        <div class="col-sm-4"></div>
            <div class="col-sm-3 shadow">
                <form>
                    <div class=" row mt-2">
                        <h2 class="text-center">User Registration</h2>
                    </div>

                       <!-- FULL NAME -->
                     <div class="mt-2">
                        <!-- <label class="form-label text-light">Last Name -</label> -->
                        <input class="form-control" type="text" name="t2" value=""  placeholder="Full Name"required/>
                    </div>


                    <!--E-MAIL -->
                     <div class="mt-2">
                        <!-- <label class="form-label text-light">Last Name -</label> -->
                        <input class="form-control" type="email" name="t2" value=""  placeholder="E-mail"required/>
                    </div>

                    <!--PASSWORD -->
                     <div class="mt-2">
                        <!-- <label class="form-label text-light">Last Name -</label> -->
                        <input class="form-control" type="password" name="t2" value=""  placeholder="Password"required/>
                    </div>

                    <!--CONFIRM PASSWORD -->
                     <div class="mt-2">
                        <!-- <label class="form-label text-light">Last Name -</label> -->
                        <input class="form-control" type="password" name="t2" value=""  placeholder="Confirm Password"required/>
                    </div>

                    <!-- GENDER -->
                    <div class="mt-2">
                        <!-- <label class="form-label text-light" >Choose Gender</label> -->
                        <select class="form-select" name="t3">
                            <option >Choose Gender</option>
                            <option>Male</option>
                            <option>Female</option>
                        </select>

                    </div>
                    <!-- GENDER -->
                     <!-- <div class="mt-2">
                        <label class="form-label text-light" required>Gender</label> &nbsp; &nbsp;
                        <label class="text-light">
                            <input class="form-check-input" type="radio" name="t6" value="Male"/> Male  &nbsp; &nbsp; &nbsp;
                        </label>

                        <label class="text-light">
                            <input class="form-check-input" type="radio" name="t7" value="Female" /> Female
                        </label>
                     </div> -->

                    <!--MOBILE NUMBER -->
                     <div class="mt-2">
                        <!-- <label class="form-label text-light">E-mail -</label> -->
                        <input class="form-control" type="text" name="t8" value=""  placeholder="Mobile Number"required/>
                    </div>
                    
                    <!-- BUTTON -->
                     <div class="col-sm-12 mt-5 mb-5">
                        <div class="d-grid">
                        <button class="btn btn-primary btn-outline-info btn-block text-light" type="submit">Register</button>
                    </div>
                     </div>
                </form>
             </div>
            </div>
    <?php include_once "../footer.php" ?>
</div>
</body>

</html>